# Echelon B2B Funnel

Ready-deployable Netlify funnel for Echelon Acquisitions.

## Deploy

Deploy this folder to Netlify.

- Publish directory: `.`
- Functions directory: `netlify/functions`
- Main page: `index.html`
- Confirmation page: `/confirmed`

## Environment Variables

The lead intake form posts to `/.netlify/functions/ghl-contact`, which forwards the lead to HighLevel.

Required Netlify environment variables:

- `GHL_API_KEY`
- `GHL_LOCATION_ID`

The browser never sees these values.

## Front Page

The first screen uses a React intake form mounted at `#lead-intake-root`.

Form steps:

1. Service area
2. Yearly revenue range
3. Full name, business name, email, phone

On a successful GHL response, the form fires `fbq("track", "Lead")` when a Meta Pixel is present, then redirects to `/confirmed`.

## Files

- `index.html` - main funnel page
- `lead-intake-form.js` - React multi-step intake form
- `netlify/functions/ghl-contact.js` - HighLevel contact forwarding function
- `styles.css` - funnel design
- `confirmed/index.html` - success page
- `netlify.toml` - Netlify deploy config
