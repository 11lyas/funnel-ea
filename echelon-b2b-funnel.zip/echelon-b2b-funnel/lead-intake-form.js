(function () {
  const root = document.getElementById("lead-intake-root");
  if (!root || !window.React || !window.ReactDOM) return;

  const { useState } = window.React;
  const e = window.React.createElement;

  const revenueOptions = [
    "Under $500k/year",
    "$500k-$1M/year",
    "$1M-$2.5M/year",
    "$2.5M+/year"
  ];

  const initialForm = {
    serviceArea: "",
    yearlyRevenue: "",
    fullName: "",
    businessName: "",
    email: "",
    phone: ""
  };

  const inputClass =
    "h-[58px] w-full rounded-[6px] border border-[#d8d8d8] bg-white px-4 text-[18px] font-semibold text-black outline-none transition focus:border-[#4da1f7] focus:ring-2 focus:ring-[#4da1f7]/25";

  function LeadIntakeForm() {
    const [step, setStep] = useState(1);
    const [form, setForm] = useState(initialForm);
    const [error, setError] = useState("");
    const [submitting, setSubmitting] = useState(false);

    function updateField(field, value) {
      setForm((current) => ({ ...current, [field]: value }));
      setError("");
    }

    function validateStep(currentStep) {
      if (currentStep === 1 && !form.serviceArea.trim()) {
        return "Please enter the area you service.";
      }

      if (currentStep === 2 && !form.yearlyRevenue) {
        return "Please select your yearly revenue range.";
      }

      if (currentStep === 3) {
        if (!form.fullName.trim()) return "Please enter your full name.";
        if (!form.businessName.trim()) return "Please enter your business name.";
        if (!form.email.trim()) return "Please enter your email.";
        if (!form.phone.trim()) return "Please enter your phone number.";
      }

      return "";
    }

    async function submitLead() {
      setSubmitting(true);
      setError("");

      try {
        const response = await fetch("/.netlify/functions/ghl-contact", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(form)
        });

        const payload = await response.json().catch(() => ({}));

        if (!response.ok || !payload.ok) {
          throw new Error(payload.error || "Something went wrong. Please try again.");
        }

        if (window.fbq) {
          window.fbq("track", "Lead");
        }

        window.location.href = "/confirmed";
      } catch (err) {
        setError(err.message || "Something went wrong. Please try again.");
      } finally {
        setSubmitting(false);
      }
    }

    async function handleAction() {
      const validationError = validateStep(step);
      if (validationError) {
        setError(validationError);
        return;
      }

      if (step < 3) {
        setStep((current) => current + 1);
        return;
      }

      await submitLead();
    }

    function renderStep() {
      if (step === 1) {
        return e(
          "label",
          { className: "grid gap-5 text-left" },
          e("span", { className: "text-[28px] font-black leading-[1.7] text-black sm:text-[31px]" }, "What area do you service? *"),
          e("input", {
            className: inputClass,
            type: "text",
            value: form.serviceArea,
            placeholder: "Dallas, TX",
            autoComplete: "address-level2",
            onChange: (event) => updateField("serviceArea", event.target.value)
          })
        );
      }

      if (step === 2) {
        return e(
          "div",
          { className: "text-left" },
          e("p", { className: "mb-7 text-[28px] font-black leading-[1.45] text-black sm:text-[31px]" }, "What is your yearly revenue range? *"),
          e(
            "div",
            { className: "grid gap-5" },
            revenueOptions.map((option) => {
              const selected = form.yearlyRevenue === option;

              return e(
                "button",
                {
                  key: option,
                  type: "button",
                  className: "flex min-h-[44px] items-center gap-5 bg-transparent p-0 text-left text-[27px] font-black leading-tight text-black",
                  onClick: () => updateField("yearlyRevenue", option)
                },
                e("span", {
                  className: [
                    "grid h-[31px] w-[31px] shrink-0 place-items-center rounded-full border-2",
                    selected ? "border-[#4da1f7]" : "border-[#8e8e8e]"
                  ].join(" ")
                }, selected ? e("span", { className: "h-[17px] w-[17px] rounded-full bg-[#4da1f7]" }) : null),
                e("span", null, option)
              );
            })
          )
        );
      }

      return e(
        "div",
        { className: "grid gap-4 text-left sm:grid-cols-2" },
        e(
          "label",
          { className: "grid gap-2" },
          e("span", { className: "text-[18px] font-black text-black" }, "Full Name *"),
          e("input", {
            className: inputClass,
            type: "text",
            value: form.fullName,
            autoComplete: "name",
            onChange: (event) => updateField("fullName", event.target.value)
          })
        ),
        e(
          "label",
          { className: "grid gap-2" },
          e("span", { className: "text-[18px] font-black text-black" }, "Business Name *"),
          e("input", {
            className: inputClass,
            type: "text",
            value: form.businessName,
            autoComplete: "organization",
            onChange: (event) => updateField("businessName", event.target.value)
          })
        ),
        e(
          "label",
          { className: "grid gap-2" },
          e("span", { className: "text-[18px] font-black text-black" }, "Email *"),
          e("input", {
            className: inputClass,
            type: "email",
            value: form.email,
            autoComplete: "email",
            onChange: (event) => updateField("email", event.target.value)
          })
        ),
        e(
          "label",
          { className: "grid gap-2" },
          e("span", { className: "text-[18px] font-black text-black" }, "Phone *"),
          e("input", {
            className: inputClass,
            type: "tel",
            value: form.phone,
            autoComplete: "tel",
            onChange: (event) => updateField("phone", event.target.value)
          })
        )
      );
    }

    return e(
      "div",
      { className: "mx-auto mt-20 w-full max-w-[807px] overflow-hidden rounded-[11px] border-[5px] border-[#4da1f7] bg-white text-left shadow-none" },
      e(
        "div",
        { className: "min-h-[360px] bg-white px-[42px] pb-[42px] pt-[110px] text-black sm:px-[86px]" },
        e("div", { className: "mb-4 h-[16px] w-full bg-[#f7c99b]" }),
        renderStep(),
        error ? e("p", { className: "mt-5 text-[16px] font-bold text-[#bb2529]" }, error) : null
      ),
      e(
        "button",
        {
          type: "button",
          className: "flex min-h-[106px] w-full items-center justify-end bg-[#55a3f7] px-[48px] text-[36px] font-black uppercase tracking-[0.03em] text-white transition hover:bg-[#438fe0] disabled:cursor-not-allowed disabled:opacity-70",
          disabled: submitting,
          onClick: handleAction
        },
        submitting ? "SUBMITTING" : step === 3 ? "SUBMIT" : "NEXT \u2192"
      )
    );
  }

  window.ReactDOM.createRoot(root).render(e(LeadIntakeForm));
})();
