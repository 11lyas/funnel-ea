const CONTACTS_URL = "https://services.leadconnectorhq.com/contacts/";

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  };
}

function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}

function splitName(fullName) {
  const parts = fullName.split(/\s+/).filter(Boolean);
  const firstName = parts.shift() || fullName;
  const lastName = parts.join(" ");
  return { firstName, lastName };
}

exports.handler = async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return json(204, {});
  }

  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, error: "Method not allowed." });
  }

  const apiKey = process.env.GHL_API_KEY;
  const locationId = process.env.GHL_LOCATION_ID;

  if (!apiKey || !locationId) {
    return json(500, { ok: false, error: "GHL integration is missing environment variables." });
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (error) {
    return json(400, { ok: false, error: "Invalid request body." });
  }

  const serviceArea = clean(body.serviceArea);
  const yearlyRevenue = clean(body.yearlyRevenue);
  const fullName = clean(body.fullName);
  const businessName = clean(body.businessName);
  const email = clean(body.email);
  const phone = clean(body.phone);

  if (!serviceArea || !yearlyRevenue || !fullName || !businessName || !email || !phone) {
    return json(400, { ok: false, error: "Missing required fields." });
  }

  const { firstName, lastName } = splitName(fullName);
  const source = `Echelon Front Page Intake | Area: ${serviceArea} | Revenue: ${yearlyRevenue}`;

  const contactPayload = {
    locationId,
    firstName,
    lastName,
    name: fullName,
    email,
    phone,
    companyName: businessName,
    source,
    tags: ["echelon-front-page", "kitchen-bath-remodeler", "paid-ads-funnel"]
  };

  try {
    const response = await fetch(CONTACTS_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        Accept: "application/json",
        Version: "v3"
      },
      body: JSON.stringify(contactPayload)
    });

    const responseText = await response.text();
    let responseBody = {};

    try {
      responseBody = responseText ? JSON.parse(responseText) : {};
    } catch (error) {
      responseBody = { raw: responseText };
    }

    if (!response.ok) {
      return json(response.status, {
        ok: false,
        error: responseBody.message || responseBody.error || "GoHighLevel rejected the contact.",
        traceId: responseBody.traceId
      });
    }

    return json(200, {
      ok: true,
      contactId: responseBody.contact && responseBody.contact.id ? responseBody.contact.id : responseBody.id
    });
  } catch (error) {
    return json(500, { ok: false, error: "Could not connect to GoHighLevel." });
  }
};
