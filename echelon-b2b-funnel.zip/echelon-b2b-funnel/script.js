(function () {
  const year = document.getElementById("year");
  if (year) {
    year.textContent = new Date().getFullYear();
  }

  // Add your GoHighLevel booking slug here when you have it.
  // Example slug: "abc123xyz"
  // Full embed URL will become:
  // https://api.leadconnectorhq.com/widget/booking/abc123xyz
  const GHL_BOOKING_SLUG = "";

  // If you prefer, paste the complete GHL booking URL here instead.
  const GHL_BOOKING_URL = "";

  const bookingFrame = document.querySelector("[data-booking-frame]");
  const bookingCard = document.querySelector(".booking-card");
  const calendarUrl = GHL_BOOKING_URL || (GHL_BOOKING_SLUG ? `https://api.leadconnectorhq.com/widget/booking/${GHL_BOOKING_SLUG}` : "");

  if (bookingFrame && bookingCard && calendarUrl) {
    bookingFrame.src = calendarUrl;
    bookingCard.classList.add("has-calendar");
  }

  const carousel = document.querySelector("[data-carousel]");
  const prev = document.querySelector("[data-carousel-prev]");
  const next = document.querySelector("[data-carousel-next]");

  function moveCarousel(direction) {
    if (!carousel) return;
    const amount = Math.max(320, carousel.clientWidth * 0.82);
    carousel.scrollBy({ left: direction * amount, behavior: "smooth" });
  }

  if (prev) prev.addEventListener("click", () => moveCarousel(-1));
  if (next) next.addEventListener("click", () => moveCarousel(1));

  document.querySelectorAll("form").forEach((form) => {
    form.addEventListener("submit", () => {
      if (window.fbq) {
        window.fbq("track", "Lead");
      }
    });
  });
})();
